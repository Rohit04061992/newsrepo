package com.newsservice.searchnews.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.newsservice.searchnews.configuration.NewsApiConfig;
import com.newsservice.searchnews.constants.INTERVAL;

import com.newsservice.searchnews.dao.NewsEntity;
import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dto.News;
import com.newsservice.searchnews.repository.NewsRepository;
import com.newsservice.searchnews.utility.NewsUtility;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NewsService {


    @Autowired
    private NewsApiConfig newsApiConfig;

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private NewsRepository newsRepository;


    private static  final String strPattern = "[~!@#$%^&*()_+{}\\[\\]:;,.<>/?-]";


    public List<Article> getNewsByInterval(String sub, String interval, String n, Integer pageSize) throws IOException, InterruptedException {


        final  Optional<Instant> timestampEnd=defineTimeStamp(INTERVAL.valueOf(interval),Integer.parseInt(n));
        log.info("start time frame is {}",timestampEnd);
        if(newsRepository.findBySubFilter(sub).isEmpty()) {
            log.info("Search query is unique fetching data from Api. Search query is {}",sub);
            News news = fetchNewsFromApi(sub, interval,Integer.parseInt(n), pageSize);
            Date lastSearchedQueryTime = findLastSearchedQueryTime(sub).orElse(Date.from(Instant.now().minusSeconds(12 * 24 * 60 * 60)));
            log.info("received lastSearchedQueryTime {}", lastSearchedQueryTime);
            List<Article> filteredArticles = news.getArticles().stream().filter(article -> article.getPublishedAt().after(lastSearchedQueryTime)).collect(Collectors.toList());
            log.info("filtered articles are {}", filteredArticles.size());
            NewsEntity newsEntity = NewsUtility.convertToDao(new News(news.getStatus(), filteredArticles.size(), (ArrayList<Article>) filteredArticles), sub);
            if (newsEntity.getArticle().size() != 0) {
                storeInDatabase(Optional.of(newsEntity), sub);
                List<Article> filteredList = news.getArticles().stream().filter(article -> article.getPublishedAt().toInstant().isAfter(timestampEnd.get())).collect(Collectors.toList());

                return filteredList;
            }
        }
        log.info("Search query is not  unique fetching data Database. Search query is {}",sub);
        return newsRepository.findBySubFilter(sub).stream().flatMap(news1 -> news1.getArticle().stream()).map(article -> article).collect(Collectors.toList());


    }

    public  String createUrl(String sub, String interval, Integer n, Integer pageSize)
    {
        String parameter="q="+sub+"&from=2022-07-04&sortBy=publishedAt";
        log.info("url found is {} and key is {}",newsApiConfig.getUrl(),newsApiConfig.getApikey());
        return new String(newsApiConfig.getUrl()+"?"+parameter+"&pageSize="+pageSize+"&apiKey="+newsApiConfig.getApikey());
    }

    public void storeInDatabase(Optional<NewsEntity> news, String sub){
        news.get().setSubFilter(sub);
        news.get().setLastSearchTime(Date.from(Instant.now()));
        // new MongoTemplate(mongoConfig.mongoClient(), "newsservice").save(news.get());
        newsRepository.save(news.get());

    }

    public static  Optional<Instant>   defineTimeStamp(INTERVAL interval,Integer n){
        Instant timestamp1= Instant.now();
        Optional<Instant> timestampEnd=Optional.empty();
        switch(interval){
            case MIN :
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*60));
                break;
            case HOUR :
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*60*60));
                break;
            case DAY :
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*86400));
                break;
            case WEEK :
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*86400*7));
                break;
            case MONTH :
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*86400*30));
                break;
            case YEAR:
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*86400*30*12));
                break;
            default:
                timestampEnd= Optional.of(timestamp1.minusSeconds(n*86400*12));
                break;
        }
        return  timestampEnd;
    }

    @HystrixCommand(fallbackMethod = "fallbackNewsApi")
    public News fetchNewsFromApi(String sub, String interval, Integer n, Integer pageSize)  {

        HttpClient client = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(createUrl(sub, interval, n, 10))).build();
        HttpResponse response = null;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Optional<News> news = Optional.empty();
        log.info("URI used for the call is {}",createUrl(sub, interval, n, 10));
        log.info("News api call response is   {} ",response.statusCode());
        log.info("result of response.statusCode().equals(200) is {}",response.statusCode()==200);
        if (response.statusCode()==200) {
            log.info("starting the parsing of received news response   ");
            String responseBody = (String) response.body();
            ObjectMapper mapper = new ObjectMapper();
            try {
                news = Optional.ofNullable(mapper.readValue(responseBody, News.class));
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
            log.info("News received contains  {} elements",news.get().getTotalResults());
        }
        return news.get();
    }

    public Optional<Date> findLastSearchedQueryTime(String querySub){
        return newsRepository.findBySubFilter(querySub).stream().sorted(Comparator.comparing(NewsEntity::getLastSearchTime).reversed()).map(newsEntity -> newsEntity.getLastSearchTime()).findFirst();

    }

    public static  boolean isSubValid(String subject){
        Pattern p =Pattern.compile(strPattern);
        Matcher m=p.matcher(subject);
        if(m.find()){
            return false;
        }
        log.info("returning true from isSubValid");
        return true;
    }

    public static  boolean isIntervalValid(String interval){
        Pattern p =Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Matcher m=p.matcher(interval);
        if(m.find()&& Arrays.asList("MONTH","DAY","MIN").contains(interval)){
            return false;
        }
        log.info("returning true from isIntervalValid");
        return true;
    }

    public static  boolean isIntervalDurationValid(String interval){
        Pattern p =Pattern.compile("[a-zA-Z]", Pattern.CASE_INSENSITIVE);
        Matcher m=p.matcher(interval);
        if(m.find()||Integer.parseInt(interval)>5000){
            log.info("inside find for {}",interval);
            return false;
        }
        log.info("returning true from isIntervalDurationValid");
        return true;
    }


    private List<News> fallbackNewsApi(String sub,String interval,Integer n,Integer pageSize) {
        return newsRepository.findAll().stream().map(newsEntity -> NewsUtility.convertToDto(newsEntity)).collect(Collectors.toList());
    }

}
