package com.newsservice.searchnews.controller;


import com.newsservice.searchnews.constants.INTERVAL;
import com.newsservice.searchnews.dao.Subscription;
import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dto.News;
import com.newsservice.searchnews.dto.NewsResponseEntity;
import com.newsservice.searchnews.dto.UserSubscription;
import com.newsservice.searchnews.exception.InvalidSearchQueryException;
import com.newsservice.searchnews.exception.SubscriptionNotFoundException;
import com.newsservice.searchnews.exception.SubscriptionPersistanceException;
import com.newsservice.searchnews.service.NewsService;
import com.newsservice.searchnews.service.SubscriptionService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;

import java.io.IOException;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(value = "/api")
@OpenAPIDefinition(
        info = @Info(
                title = "News Service",
                version = "1.0",
                description = "News service offers news api from where user can get the news on any favourite topic on the basis of time frame ",
                license = @License(name = "Apache 2.0", url = "http://news-service:9880"),
                contact = @Contact(url = "http://news-service:9880", name = "user")
        )
)
@Slf4j
public class NewsController {

    @Autowired
    private NewsService newsService;

    @Autowired
    private SubscriptionService subscriptionService;



    @Operation(summary = "Get all subscriptions for mentioned subject")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found the subscription",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Subscription.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid Subject supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Subscription not found",
                    content = @Content) })
    @GetMapping(value = "/listSubscription",produces = MediaType.APPLICATION_JSON_VALUE)
    public  ResponseEntity<List<Subscription>> getSubscriptions(@RequestParam(name = "subject") String sub) {


        List<Subscription> subscriptionList=subscriptionService.findAll(sub);
        if(subscriptionList.size()==0){
            throw new SubscriptionNotFoundException();
        }
        return new ResponseEntity<>(subscriptionList,HttpStatus.OK);


    }


    @Operation(summary = "Create Subscription for favourite subjects ")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created  the subscription",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Subscription.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid Subject supplied",
                    content = @Content) })
    @PostMapping(value = "/subscription",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Subscription> create(@RequestBody UserSubscription subscription) {
        UserDetails principal = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.info("Principle received is "+principal.getUsername());
        Optional<List<String >> subjects=Optional.ofNullable(subscription.getSubjects());
        log.info("received sub is "+subjects.get());

        Subscription subscriptionEntity = subscriptionService.save(new Subscription(principal.getUsername(),subscription.getSubjects()));
        log.info("saved subscription entity is "+ subscriptionEntity);
        if (subscriptionEntity == null) {
            throw new SubscriptionPersistanceException();
        } else {
            return new ResponseEntity<>(subscriptionEntity, HttpStatus.CREATED);
        }
    }

    @Operation(summary = "Get News for mentioned subject, interval , interval value ")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found the news ",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Subscription.class)) }),
            @ApiResponse(responseCode = "400", description = "Invalid input parameters  supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "News  not found",
                    content = @Content) })
    @GetMapping(value = "/news",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<NewsResponseEntity> listNews(@RequestParam("sub") String sub,
                                                       @RequestParam(required = false) String interval,
                                                       @RequestParam(required = false) String n,
                                                       @RequestParam(required = false) Integer pageSize) throws IOException, InterruptedException {

        if(!NewsService.isSubValid(sub)||!NewsService.isIntervalValid(interval)||!NewsService.isIntervalDurationValid(n)){

            throw new InvalidSearchQueryException();
        }

        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.info("Principle received is "+ principal.getUsername());
        Optional<News> news = Optional.empty();
        Optional<String> intervalType = Optional.ofNullable(interval);
        Optional<String> number = Optional.ofNullable(n);
        Optional<Integer> page = Optional.ofNullable(pageSize);
        Optional<List<Article>> articles = Optional.of(newsService.getNewsByInterval(sub, intervalType.orElse(String.valueOf(INTERVAL.HOUR)), n, page.orElse(Integer.valueOf(10))));

        return new ResponseEntity<>(new NewsResponseEntity(interval,articles.get().size(),articles.get()), HttpStatus.OK);


    }



}