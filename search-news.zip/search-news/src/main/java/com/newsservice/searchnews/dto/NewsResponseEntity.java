package com.newsservice.searchnews.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsResponseEntity {

    private String IntervalGroup;

    private int countOfEntry;

    private List<Article> articleList;
}
