package com.newsservice.searchnews;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.newsservice.searchnews.configuration.NewsApiConfig;
import com.newsservice.searchnews.controller.NewsController;
import com.newsservice.searchnews.dao.NewsEntity;
import com.newsservice.searchnews.dao.Subscription;
import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dto.UserSubscription;
import com.newsservice.searchnews.repository.NewsRepository;
import com.newsservice.searchnews.repository.SubscriptionRepository;
import com.newsservice.searchnews.service.NewsService;
import com.newsservice.searchnews.service.SubscriptionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@SpringBootTest
@ExtendWith(MockitoExtension.class)
@EnableAutoConfiguration(exclude = { SecurityAutoConfiguration.class })
@EnableConfigurationProperties(value = NewsApiConfig.class)
@TestPropertySource("classpath:application-dev.properties")
class SearchNewsApplicationTests {

	@InjectMocks
	private NewsController newsController;



	@SpyBean
	NewsService newsService;


	@Mock
	NewsApiConfig newsApiConfig;


	@SpyBean
	NewsRepository newsRepository;

	@Mock
	SubscriptionService subscriptionService;

	@Mock
	SubscriptionRepository subscriptionRepository;

	private static final NewsEntity entity1=new NewsEntity("ok","india",1, Arrays.asList(
			Article.builder()
					.author("Tim Cullinan")
					.description("Proposed limits on sectoral emissions do not take into account impact on incomes and production")
					.content("").publishedAt(new Date()).build()),new Date());

	private static final NewsEntity entity2=new NewsEntity("ok","india",1, Arrays.asList(
			Article.builder()
					.author("Tim cook")
					.description("Proposed limits on sectoral emissions do not take into account impact on incomes and production")
					.content("").publishedAt(new Date()).build()),new Date());


	private static final String dummySubscription="{\n" +
			"  \"subjects\": [\n" +
			"    \"japan\"\n" +
			"  ]\n" +
			"}";


	@WithMockUser
	@Test
	void testGetOfNews() throws IOException, InterruptedException {
		final ObjectMapper objectMapper = new ObjectMapper();
		MockHttpServletRequest request=new MockHttpServletRequest();

		when(newsRepository.findBySubFilter(anyString())).thenReturn(Arrays.asList(entity1,entity2));

		ResponseEntity<List<Article>> response=newsController.listNews("india","DAY","10",2);
		assertThat(response.getStatusCode().is2xxSuccessful());
		assertThat(response.getBody().size()==2);


	}
	@WithMockUser
	@Test
	void testCreateOfSubscription() {

		Subscription subscription=new Subscription("user",Arrays.asList("japan"));

		//lenient().when(subscriptionRepository.save(any(Subscription.class))).thenReturn(subscription);
		lenient().when(subscriptionService.save(any(Subscription.class))).thenReturn(subscription);
		ResponseEntity<Subscription> response=newsController.create(new UserSubscription(Arrays.asList("japan")));
		assertThat(response.getBody().getUsername().equals("user"));
		//assertThat(response.getBody()==2);


	}


	@WithMockUser
	@Test
	void testPrincipal() {
		assertThat(((UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername().equals("user"));
		//assertThat(response.getBody()==2);


	}

	@WithMockUser(username = "testuser",roles = {"User"})
	@Test
	void testAuthorities() {
		assertThat((SecurityContextHolder.getContext().getAuthentication().getAuthorities().contains("User")));



	}

	@Test
	void testValidateInterval(){
		assertThat(NewsService.isIntervalValid("Day")==Boolean.FALSE);

	}


	@Test
	void testValidateSub(){
		assertThat(NewsService.isSubValid("Day34")==Boolean.FALSE);

	}

	@Test
	void testValidateN(){
		assertThat(NewsService.isIntervalDurationValid("Day34")==Boolean.FALSE);

	}
}
