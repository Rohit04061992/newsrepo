package com.newsservice.searchnews.utility;


import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dao.NewsEntity;
import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dto.News;
import com.newsservice.searchnews.dto.Source;
import org.springframework.stereotype.Component;

import javax.xml.crypto.Data;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class NewsUtility {

    public News convertToDto(NewsEntity newsEntity){

        return new News(newsEntity.getStatus(),newsEntity.getTotalResults(), (ArrayList<Article>) newsEntity.getArticle());

    }

    public static NewsEntity convertToDao(News news, String sub){
        return new NewsEntity(news.getStatus(),sub,news.getTotalResults(),news.getArticles(), Date.from(Instant.now()));

    }
/*
    public List<Article> convertToArticleDto(List<ArticleEntity> news){
        return   news.stream().map(articleEntity -> {
            return  new Article(new Source(articleEntity.getSourceEntity().getId(),articleEntity.getSourceEntity().getName()),
                    articleEntity.getAuthor(),
                    articleEntity.getTitle(),
                    articleEntity.getDescription(),
                    articleEntity.getUrl(),
                    articleEntity.getUrlToImage(),
                    articleEntity.getPublishedAt(),
                    articleEntity.getContent());


        }).collect(Collectors.toList());

    }*/
 /*   public List<ArticleEntity> convertToArticleDao(List<Article> news){
        return   news.stream().map(article -> {
            return  new ArticleEntity(new Source(article.getSource().getId(),article.getSource().getName()),
                    article.getAuthor(),
                    article.getTitle(),
                    article.getDescription(),
                    article.getUrl(),
                    article.getUrlToImage(),
                    article.getPublishedAt(),
                    article.getContent());


        }).collect(Collectors.toList());

    }*/
}
