package com.newsservice.searchnews.exception;


public class SubscriptionNotFoundException extends RuntimeException {


}
