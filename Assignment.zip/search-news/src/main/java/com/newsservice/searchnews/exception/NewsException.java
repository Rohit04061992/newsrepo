package com.newsservice.searchnews.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class NewsException extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = {NullPointerException.class, HttpClientErrorException.BadRequest.class})
    protected ResponseEntity<Object> handleConflict(RuntimeException ex, WebRequest request){
        String bodyOfResponse = "Some Thing Bad Happened at News Service";
        return handleExceptionInternal(ex, bodyOfResponse,
                new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);

    }
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = {InvalidSearchQueryException.class})
    protected ResponseEntity<Object> handleBadQuerySearch(RuntimeException ex, WebRequest request){
        String bodyOfResponse = "Either of Search Query/Interval/Value of N is not valid";
        return handleExceptionInternal(ex, bodyOfResponse,
                new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

    }
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = {SubscriptionPersistanceException.class})
    protected ResponseEntity<Object> handleSubscriptionSaveFailure(RuntimeException ex, WebRequest request){
        String bodyOfResponse = "Subscription was not getting saved";
        return handleExceptionInternal(ex, bodyOfResponse,
                new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);

    }
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = {SubscriptionNotFoundException.class})
    protected ResponseEntity<Object> handleSubscriptionNotFoundFailure(RuntimeException ex, WebRequest request){
        String bodyOfResponse = "Subscription was not found ";
        return handleExceptionInternal(ex, bodyOfResponse,
                new HttpHeaders(), HttpStatus.NOT_FOUND, request);

    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = {NewsApiCallException.class})
    protected ResponseEntity<Object> handleNewsApiFailure(RuntimeException ex, WebRequest request){
        String bodyOfResponse = "News api communication failure / News api is Down ";
        return handleExceptionInternal(ex, bodyOfResponse,
                new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);

    }


}
