package com.newsservice.searchnews.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
public class News {
    private String status;
    private int totalResults;
    private ArrayList<Article> articles;

    public News(String status, int totalResults, ArrayList<Article> articles) {
        this.status = status;
        this.totalResults = totalResults;
        this.articles = articles;
    }

    public News() {
    }
}
