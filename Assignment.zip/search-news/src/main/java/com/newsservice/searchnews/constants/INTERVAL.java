package com.newsservice.searchnews.constants;


import lombok.ToString;

@ToString
public enum INTERVAL {
    MIN,HOUR,DAY,WEEK,MONTH,YEAR;



}
