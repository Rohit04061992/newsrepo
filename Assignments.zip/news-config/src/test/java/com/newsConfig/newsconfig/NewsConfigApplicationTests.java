package com.newsConfig.newsconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
