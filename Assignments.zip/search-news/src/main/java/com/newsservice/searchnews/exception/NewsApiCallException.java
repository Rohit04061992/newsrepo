package com.newsservice.searchnews.exception;

public class NewsApiCallException extends RuntimeException{
}
