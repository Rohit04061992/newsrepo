package com.newsservice.searchnews.exception;

public class InvalidSearchQueryException  extends RuntimeException{

}
