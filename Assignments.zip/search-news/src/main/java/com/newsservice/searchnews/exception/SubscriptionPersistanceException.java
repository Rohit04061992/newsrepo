package com.newsservice.searchnews.exception;

public class SubscriptionPersistanceException extends  RuntimeException{
}
