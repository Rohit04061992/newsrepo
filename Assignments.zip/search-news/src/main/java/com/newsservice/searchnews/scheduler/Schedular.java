package com.newsservice.searchnews.scheduler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.newsservice.searchnews.dao.NewsEntity;
import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dto.News;
import com.newsservice.searchnews.repository.SubscriptionRepository;
import com.newsservice.searchnews.service.NewsService;
import com.newsservice.searchnews.service.SubscriptionService;
import com.newsservice.searchnews.utility.NewsUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.text.SimpleDateFormat;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@Slf4j
public class Schedular {

    @Autowired
            private NewsService newsService;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @Scheduled(fixedRate = 60000,initialDelay = 3000)
    public void retrieveNewsForSubscriptions() {
        log.info("The time is now {}", dateFormat.format(new Date()));
        List<String> subList=subscriptionRepository.findAll().stream().flatMap(subscription -> subscription.getSubjects().stream()).map(s -> s).collect(Collectors.toList());
        log.info("sublist is {}",subList);
       if(!subList.isEmpty()){

           subList.parallelStream().forEach(sub->{


               News news = newsService.fetchNewsFromApi(sub,"MIN",5,500);
               log.info("received news response contains {}",news.getTotalResults());
               Date lastSearchedQueryTime=newsService.findLastSearchedQueryTime(sub).orElse(Date.from(Instant.now().minusSeconds(12*24*60*60)));
               log.info("received lastSearchedQueryTime {}",lastSearchedQueryTime );
               List<Article> filteredArticles = news.getArticles().stream().filter(article -> article.getPublishedAt().after(lastSearchedQueryTime)).collect(Collectors.toList());
               log.info("filtered articles are {}",filteredArticles.size());
               NewsEntity newsEntity= NewsUtility.convertToDao(new News(news.getStatus(),filteredArticles.size(), (ArrayList<Article>) filteredArticles),sub);
               if(newsEntity.getArticle().size()!=0){
                   newsService.storeInDatabase(Optional.of(newsEntity),sub);
               }


           });
       }
    }


}
