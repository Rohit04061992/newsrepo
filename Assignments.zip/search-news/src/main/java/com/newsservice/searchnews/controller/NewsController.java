package com.newsservice.searchnews.controller;


import com.newsservice.searchnews.constants.INTERVAL;
import com.newsservice.searchnews.dao.Subscription;
import com.newsservice.searchnews.dto.Article;
import com.newsservice.searchnews.dto.News;
import com.newsservice.searchnews.dto.UserSubscription;
import com.newsservice.searchnews.exception.InvalidSearchQueryException;
import com.newsservice.searchnews.exception.SubscriptionNotFoundException;
import com.newsservice.searchnews.exception.SubscriptionPersistanceException;
import com.newsservice.searchnews.service.NewsService;
import com.newsservice.searchnews.service.SubscriptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;

import java.io.IOException;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(value = "/api")
@Slf4j
public class NewsController {



    @Autowired
    private NewsService newsService;

    @Autowired
    private SubscriptionService subscriptionService;




    @GetMapping(value = "/listSubscription",produces = MediaType.APPLICATION_JSON_VALUE)
    public  ResponseEntity<List<Subscription>> getNews(@RequestParam(name = "subject") String sub) {


        List<Subscription> subscriptionList=subscriptionService.findAll(sub);
        if(subscriptionList.size()==0){
            throw new SubscriptionNotFoundException();
        }
        return new ResponseEntity<>(subscriptionList,HttpStatus.OK);


    }



    @PostMapping(value = "/subscription",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Subscription> create(@RequestBody UserSubscription subscription) {
        UserDetails principal = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.info("Principle received is "+principal.getUsername());
        Optional<List<String >> subjects=Optional.ofNullable(subscription.getSubjects());
        log.info("received sub is "+subjects.get());

        Subscription subscriptionEntity = subscriptionService.save(new Subscription(principal.getUsername(),subscription.getSubjects()));
        log.info("saved subscription entity is "+ subscriptionEntity);
        if (subscriptionEntity == null) {
            throw new SubscriptionPersistanceException();
        } else {
            return new ResponseEntity<>(subscriptionEntity, HttpStatus.CREATED);
        }
    }

    @GetMapping(value = "/news",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Article>> listNews(@RequestParam("sub") String sub,
                                                  @RequestParam(required = false) String interval,
                                                  @RequestParam(required = false) String n,
                                                  @RequestParam(required = false) Integer pageSize) throws IOException, InterruptedException {

        if(!NewsService.isSubValid(sub)||!NewsService.isIntervalValid(interval)||!NewsService.isIntervalDurationValid(n)){

            throw new InvalidSearchQueryException();
        }

        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.info("Principle recieved is "+ principal.getUsername());
        Optional<News> news = Optional.empty();
        Optional<String> intervalType = Optional.ofNullable(interval);
        Optional<String> number = Optional.ofNullable(n);
        Optional<Integer> page = Optional.ofNullable(pageSize);
        Optional<List<Article>> articles = Optional.of(newsService.getNewsByInterval(sub, intervalType.orElse(String.valueOf(INTERVAL.HOUR)), n, page.orElse(Integer.valueOf(10))));

        return new ResponseEntity<>(articles.get(), HttpStatus.OK);


    }



}