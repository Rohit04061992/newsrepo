package com.newsservice.searchnews.service;

import com.newsservice.searchnews.dao.Subscription;
import com.newsservice.searchnews.repository.SubscriptionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SubscriptionService {


    @Autowired
    private SubscriptionRepository subscriptionRepository;


    public Subscription save(Subscription subscription){
       Optional<Subscription> subscriptionPresent= findByName(subscription.getUsername()).stream().findFirst();
       if(subscriptionPresent.isPresent()){
           subscriptionPresent.get().setSubjects(subscription.getSubjects());
           return subscriptionRepository.save(subscriptionPresent.get());
       }

        return subscriptionRepository.save(subscription);
    }

    public List<Subscription> findAll(String subFilter){
        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.info("Principle received is "+ principal.getUsername());
        log.info(subscriptionRepository.findAll().stream().filter(sub ->sub.getUsername().equals(principal.getUsername())&&sub.getSubjects().contains(subFilter)).collect(Collectors.toList()).toString());
        return subscriptionRepository.findAll().stream().filter(sub ->sub.getUsername().equals(principal.getUsername())&&sub.getSubjects().contains(subFilter)).collect(Collectors.toList());
    }

    public List<Subscription> findAll(){

        return subscriptionRepository.findAll().stream().collect(Collectors.toList());
    }

    public List<Subscription> findByName(String name){

        return subscriptionRepository.findAll().stream().filter(subscription -> subscription.getUsername().equals(name)).collect(Collectors.toList());
    }
}
