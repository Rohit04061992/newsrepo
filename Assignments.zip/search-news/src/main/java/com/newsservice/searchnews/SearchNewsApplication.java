package com.newsservice.searchnews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableEurekaClient
@EnableScheduling
@EnableHystrix
@ComponentScan(basePackages = {"com.newsservice.searchnews.controller","com.newsservice.searchnews.configuration","com.newsservice.searchnews.*","com.newsservice.searchnews.scheduler"})
public class SearchNewsApplication {



	public static void main(String[] args) {

		SpringApplication.run(SearchNewsApplication.class, args);
	}

}
