package com.newsservice.searchnews.dao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Subscription {

    @Id
    @GeneratedValue
    private Long id;


    private String username;

    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> subjects;

    public Subscription(String username, List<String> subjects) {
        this.username = username;
        this.subjects = subjects;
    }

    @Override
    public String toString() {
        return "Subscription{" +
                "username='" + username + '\'' +
                ", subjects=" + subjects +
                '}';
    }
}
