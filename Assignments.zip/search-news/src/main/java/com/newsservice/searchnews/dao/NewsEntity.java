package com.newsservice.searchnews.dao;


import com.newsservice.searchnews.dto.Article;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Document("NewsEntity")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class NewsEntity {
    @Id
    private String id;
    private String status;
    private String subFilter;
    private int totalResults;
    private List<Article> article;
    private Date lastSearchTime;


    public NewsEntity(String status, String subFilter, int totalResults, List<Article> article, Date lastSearchTime) {
        this.status = status;
        this.subFilter = subFilter;
        this.totalResults = totalResults;
        this.article = article;
        this.lastSearchTime = lastSearchTime;
    }
}

