package com.newsservice.searchnews.configuration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import java.net.URI;

@Data
@Configuration
@ConfigurationProperties(prefix = "newsapi")
@AllArgsConstructor
@NoArgsConstructor
public class NewsApiConfig {

   @NonNull
   protected String url;

   @NonNull
   protected String apikey;


}
