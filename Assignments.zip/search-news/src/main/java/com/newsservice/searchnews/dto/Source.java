package com.newsservice.searchnews.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class Source {

    private String id;
    private String name;
}
