package com.newsservice.searchnews.repository;


import com.newsservice.searchnews.dao.NewsEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;
import java.util.UUID;

public interface NewsRepository extends MongoRepository<NewsEntity,String> {

    @Query("{subFilter:'?0'}")
    List<NewsEntity> findBySubFilter(String filter);

}
